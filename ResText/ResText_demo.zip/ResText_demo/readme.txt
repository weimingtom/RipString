Use Qt Linguist to translate nscr.sc.po.

