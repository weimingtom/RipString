/* This file is auto generated, version 2 */
#define UTS_MACHINE "arm"
#define UTS_VERSION "#2 Sat Apr 2 22:26:02 CST 2011"
#define LINUX_COMPILE_TIME "22:26:02"
#define LINUX_COMPILE_BY "wmt"
#define LINUX_COMPILE_HOST "wmt-desktop"
#define LINUX_COMPILE_DOMAIN "(none)"
#define LINUX_COMPILER "gcc version 4.5.1 (Sourcery G++ Lite 2010.09-51) "
