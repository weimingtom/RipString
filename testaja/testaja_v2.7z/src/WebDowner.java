import java.io.FileWriter;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.http.HttpEntity;
import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;

public class WebDowner {
    /**
     * @param args
     */
    public static void main(String[] args) {
	// TODO Auto-generated method stub
	FileWriter writer = null;
	try {
	    writer = new FileWriter("output.txt");
	    for (int i = 2007; i <= 2011; i++) {
		for (int j = 1; j <= 12; j++) {
		    if (i == 2007 && j < 11) continue;
		    ripString(i, j, writer);
		    try {
			Thread.sleep(1000);
		    } catch (InterruptedException e) {
			e.printStackTrace();
		    }
		}
	    }
	} catch (ClientProtocolException e) {
	    // TODO Auto-generated catch block
	    e.printStackTrace();
	} catch (IOException e) {
	    // TODO Auto-generated catch block
	    e.printStackTrace();
	} finally {
	    if (writer != null) {
		try {
		    writer.close();
		} catch (IOException e1) {
		    e1.printStackTrace();
		}
	    }
	}
    }

    public final static void ripString(int year, int month, FileWriter writer)
	    throws ClientProtocolException, IOException {
	String months = month < 10 ? "0" + month : "" + month;
	String text = getWebText("www.aja.gr.jp", 80, "http",
		"/data/datalist.php?target=point&year=" + year + "&month=" + months, 
    		"shift-jis");
	//System.out.println(text);
	Pattern pattern = Pattern.compile(
		//">([0-9]*)</td>.*\\r*\\n.*luckyNo=\"([0-9]*)\"",
		"<td bgcolor=\"#FFFFFF\" width=\"40\"><img src=\"../image/m_(.*)\\.gif\" width=\"30\" height=\"12\"></td>\\r*\\n" + 
		"<td bgcolor=\"#FFFFFF\" width=\"80\">(.*)</td>\\r*\\n" + 
		"<td bgcolor=\"#FFFFFF\" width=\"440\"><a class=\"noline\" href=\"(.*)\">(.*)</a></td>",
		Pattern.MULTILINE);
	Matcher matcher = pattern.matcher(text);
	while (matcher.find()) {
	    String str = matcher.group(1) + ", " + matcher.group(2) + 
	    	", " + matcher.group(4);
	    System.out.println(str);
	    writer.write(str + "\n");
	}
    }
    
    public final static String getWebText(String site, int port, String protocol, String uri, String encoding)
	    throws ClientProtocolException, IOException {
	DefaultHttpClient httpclient = new DefaultHttpClient();
	String text = null;
	try {
	    HttpHost target = new HttpHost(site, port, protocol);
	    HttpGet req = new HttpGet(uri);
	    HttpResponse rsp = httpclient.execute(target, req);
	    HttpEntity entity = rsp.getEntity();
	    if (entity != null) {
		text = EntityUtils.toString(entity, encoding);
	    }
	} finally {
	    httpclient.getConnectionManager().shutdown();
	}
	return text;
    }
}
